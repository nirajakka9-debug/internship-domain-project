@echo off
title Nettech Help Desk System
echo ========================================================
echo   Starting Nettech Help Desk Ticket Management System...
echo ========================================================
echo.

if exist "%~dp0maven\apache-maven-3.9.6\bin\mvn.cmd" (
    "%~dp0maven\apache-maven-3.9.6\bin\mvn.cmd" spring-boot:run
) else (
    mvn spring-boot:run
)

pause
