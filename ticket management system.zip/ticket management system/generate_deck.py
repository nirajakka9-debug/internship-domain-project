import os
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN
from pptx.enum.shapes import MSO_SHAPE

def create_presentation():
    prs = Presentation()
    prs.slide_width = Inches(13.333)
    prs.slide_height = Inches(7.5)

    # Color Palette (McKinsey / BCG Modern Executive Theme)
    BG_DARK = RGBColor(15, 23, 42)        # Deep Navy #0F172A
    CARD_BG = RGBColor(30, 41, 59)        # Slate Blue #1E293B
    ACCENT_CYAN = RGBColor(56, 189, 248)  # Electric Cyan #38BDF8
    ACCENT_GREEN = RGBColor(52, 211, 153) # Mint Green #34D399
    ACCENT_AMBER = RGBColor(251, 191, 36) # Golden Amber #FBBF24
    TEXT_WHITE = RGBColor(248, 250, 252)  # Bright White
    TEXT_MUTED = RGBColor(148, 163, 184)  # Muted Slate

    def add_blank_slide(notes_text=""):
        blank_slide_layout = prs.slide_layouts[6]
        slide = prs.slides.add_slide(blank_slide_layout)
        
        # Background shape
        bg = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, prs.slide_width, prs.slide_height)
        bg.fill.solid()
        bg.fill.fore_color.rgb = BG_DARK
        bg.line.fill.background()

        # Speaker notes
        if notes_text:
            notes_slide = slide.notes_slide
            tf = notes_slide.notes_text_frame
            tf.text = notes_text

        return slide

    def add_header(slide, category_text, title_text):
        # Category / Super-title
        cat_box = slide.shapes.add_textbox(Inches(0.8), Inches(0.4), Inches(11.7), Inches(0.4))
        tf_cat = cat_box.text_frame
        tf_cat.word_wrap = True
        p_cat = tf_cat.paragraphs[0]
        p_cat.text = category_text.upper()
        p_cat.font.size = Pt(11)
        p_cat.font.bold = True
        p_cat.font.color.rgb = ACCENT_CYAN
        p_cat.font.name = "Segoe UI"

        # Main Slide Title
        title_box = slide.shapes.add_textbox(Inches(0.8), Inches(0.7), Inches(11.7), Inches(0.8))
        tf_title = title_box.text_frame
        tf_title.word_wrap = True
        p_title = tf_title.paragraphs[0]
        p_title.text = title_text
        p_title.font.size = Pt(22)
        p_title.font.bold = True
        p_title.font.color.rgb = TEXT_WHITE
        p_title.font.name = "Segoe UI"

    def create_card(slide, left, top, width, height, bg_color=CARD_BG, border_color=None):
        card = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(left), Inches(top), Inches(width), Inches(height))
        card.fill.solid()
        card.fill.fore_color.rgb = bg_color
        if border_color:
            card.line.color.rgb = border_color
            card.line.width = Pt(1.5)
        else:
            card.line.fill.background()
        return card

    # ==========================================================
    # SLIDE 1: Title Slide
    # ==========================================================
    notes_1 = "Good morning, respected professors and panel members. Today, I am proud to present the Nettech Help Desk Ticket Management System. This is a full-stack, production-ready enterprise software platform engineered with Java 21, Spring Boot 3, and MySQL. It bridges critical communication bottlenecks in corporate IT operations by providing a structured, secure, and automated environment for issue tracking and rapid resolution."
    s1 = add_blank_slide(notes_1)
    
    # Title badge
    badge = create_card(s1, 0.8, 1.2, 3.8, 0.4, bg_color=RGBColor(14, 116, 144))
    b_tf = badge.text_frame
    b_p = b_tf.paragraphs[0]
    b_p.text = "ENTERPRISE SOFTWARE PROJECT"
    b_p.font.size = Pt(11)
    b_p.font.bold = True
    b_p.font.color.rgb = RGBColor(224, 242, 254)
    b_p.alignment = PP_ALIGN.CENTER

    tbox = s1.shapes.add_textbox(Inches(0.8), Inches(1.8), Inches(11.7), Inches(2.2))
    tf1 = tbox.text_frame
    tf1.word_wrap = True
    p1 = tf1.paragraphs[0]
    p1.text = "Nettech Help Desk\nTicket Management System"
    p1.font.size = Pt(36)
    p1.font.bold = True
    p1.font.color.rgb = TEXT_WHITE
    p1.font.name = "Segoe UI"

    p1_sub = tf1.add_paragraph()
    p1_sub.text = "An Enterprise-Grade Solution for Streamlined IT Support & Issue Lifecycle Orchestration"
    p1_sub.font.size = Pt(16)
    p1_sub.font.color.rgb = ACCENT_CYAN
    p1_sub.space_before = Pt(12)

    # Tech Badges Container
    create_card(s1, 0.8, 4.4, 11.7, 1.2, bg_color=CARD_BG)
    t_box = s1.shapes.add_textbox(Inches(1.0), Inches(4.5), Inches(11.3), Inches(1.0))
    t_tf = t_box.text_frame
    t_p = t_tf.paragraphs[0]
    t_p.text = "CORE TECH STACK & SPECIFICATIONS"
    t_p.font.size = Pt(10)
    t_p.font.bold = True
    t_p.font.color.rgb = ACCENT_AMBER
    
    t_p2 = t_tf.add_paragraph()
    t_p2.text = "• Java 21 LTS  • Spring Boot 3.2.5  • Spring Security 6  • Hibernate / JPA  • MySQL 8 (XAMPP)  • Thymeleaf"
    t_p2.font.size = Pt(13)
    t_p2.font.color.rgb = TEXT_WHITE
    t_p2.space_before = Pt(6)

    # Presenter info
    meta_box = s1.shapes.add_textbox(Inches(0.8), Inches(6.0), Inches(11.7), Inches(0.8))
    m_tf = meta_box.text_frame
    m_p = m_tf.paragraphs[0]
    m_p.text = "Submitted by: Niraj Patel  |  Master of Computer Applications (MCA)  |  BVIMIT, Mumbai University"
    m_p.font.size = Pt(12)
    m_p.font.color.rgb = TEXT_MUTED

    # ==========================================================
    # SLIDE 2: Executive Summary
    # ==========================================================
    notes_2 = "To summarize executive context: in modern organizations, ad-hoc technical support creates operational blindness. The Nettech Help Desk system transforms chaotic support tickets into an auditable, real-time pipeline. We have achieved 100% functional completion, including asynchronous notification pipelines, strict role separation, and a persistent relational database."
    s2 = add_blank_slide(notes_2)
    add_header(s2, "EXECUTIVE OVERVIEW", "Strategic Context & Core Deliverables")

    cards_data = [
        ("THE CHALLENGE", "• Informal requests via chat & email get lost.\n• Zero auditability & untracked resolution time.\n• No clear priority ranking for critical bugs.\n• Support agents overwhelmed with manual triaging.", ACCENT_AMBER),
        ("THE SOLUTION", "• Centralized, web-based support ticket hub.\n• Automated ticket state machine (Open ➔ Resolved).\n• Multi-role collaborative comment threads.\n• Automated background email notifications.", ACCENT_CYAN),
        ("KEY RESULTS", "• 100% end-to-end lifecycle traceability.\n• Sub-15ms non-blocking email dispatch.\n• Role-Based Access Control (3 Personas).\n• Full ACID-compliant MySQL database storage.", ACCENT_GREEN)
    ]

    for i, (head, body, col) in enumerate(cards_data):
        create_card(s2, 0.8 + (i * 3.9), 1.6, 3.7, 5.0)
        c_box = s2.shapes.add_textbox(Inches(1.0 + (i * 3.9)), Inches(1.8), Inches(3.3), Inches(4.6))
        c_tf = c_box.text_frame
        c_tf.word_wrap = True
        
        hp = c_tf.paragraphs[0]
        hp.text = head
        hp.font.size = Pt(14)
        hp.font.bold = True
        hp.font.color.rgb = col
        
        for line in body.split("\n"):
            bp = c_tf.add_paragraph()
            bp.text = line
            bp.font.size = Pt(12)
            bp.font.color.rgb = TEXT_WHITE
            bp.space_before = Pt(8)

    # ==========================================================
    # SLIDE 3: Problem Statement & Objectives
    # ==========================================================
    notes_3 = "When examining IT operations in scaling organizations, three failure points consistently emerge: lack of centralization, absence of priority hierarchy, and zero accountability. Our objectives directly address these pain points by deploying an automated state machine where every request is categorized, assigned, prioritized, and tracked from inception to resolution."
    s3 = add_blank_slide(notes_3)
    add_header(s3, "PROBLEM & OBJECTIVES", "Solving IT Support Bottlenecks with Structure")

    create_card(s3, 0.8, 1.6, 5.6, 5.0, border_color=RGBColor(239, 68, 68))
    p_box = s3.shapes.add_textbox(Inches(1.0), Inches(1.8), Inches(5.2), Inches(4.6))
    p_tf = p_box.text_frame
    p_tf.word_wrap = True
    ph = p_tf.paragraphs[0]
    ph.text = "⚠️ CURRENT STATE BOTTLENECKS"
    ph.font.size = Pt(14)
    ph.font.bold = True
    ph.font.color.rgb = RGBColor(248, 113, 113)

    p_items = [
        ("Siloed Communications", "Issues submitted over verbal chats or scattered email threads lack timestamps and tracking."),
        ("Ambiguous Prioritization", "Technicians cannot distinguish critical server outages from minor mousepad replacements."),
        ("No Ownership Accountability", "Tickets sit unassigned with zero visibility into technician workloads.")
    ]
    for title, desc in p_items:
        pt = p_tf.add_paragraph()
        pt.text = f"• {title}:"
        pt.font.bold = True
        pt.font.size = Pt(12)
        pt.font.color.rgb = TEXT_WHITE
        pt.space_before = Pt(8)
        pd = p_tf.add_paragraph()
        pd.text = f"  {desc}"
        pd.font.size = Pt(11)
        pd.font.color.rgb = TEXT_MUTED

    create_card(s3, 6.8, 1.6, 5.7, 5.0, border_color=ACCENT_GREEN)
    o_box = s3.shapes.add_textbox(Inches(7.0), Inches(1.8), Inches(5.3), Inches(4.6))
    o_tf = o_box.text_frame
    o_tf.word_wrap = True
    oh = o_tf.paragraphs[0]
    oh.text = "🎯 STRATEGIC PROJECT OBJECTIVES"
    oh.font.size = Pt(14)
    oh.font.bold = True
    oh.font.color.rgb = ACCENT_GREEN

    o_items = [
        ("Unified Ticketing Portal", "Single entry point for employees to raise, categorize, and follow up on issues."),
        ("4-Tier Priority Engine", "Tag tickets as Low, Medium, High, or Urgent to streamline triage response times."),
        ("Role-Based Access Governance", "Custom-tailored permissions for Employees, Technicians, and IT Administrators."),
        ("Asynchronous Alert Engine", "Dispatch automated email alerts at every status transition.")
    ]
    for title, desc in o_items:
        ot = o_tf.add_paragraph()
        ot.text = f"• {title}:"
        ot.font.bold = True
        ot.font.size = Pt(12)
        ot.font.color.rgb = TEXT_WHITE
        ot.space_before = Pt(6)
        od = o_tf.add_paragraph()
        od.text = f"  {desc}"
        od.font.size = Pt(11)
        od.font.color.rgb = TEXT_MUTED

    # ==========================================================
    # SLIDE 4: Technology Architecture & Stack
    # ==========================================================
    notes_4 = "Here we illustrate the 3-Tier Enterprise Architecture. At the Presentation Layer, Thymeleaf provides lightweight, secure server-rendered HTML integrated with Bootstrap 5. In the Business Layer, Spring Boot 3 manages dependency injection and transaction boundaries. Finally, Spring Data JPA seamlessly interfaces with MySQL, abstracting complex SQL while maintaining ACID compliance."
    s4 = add_blank_slide(notes_4)
    add_header(s4, "SYSTEM ARCHITECTURE", "3-Tier Enterprise Java Architecture")

    tiers = [
        ("1. PRESENTATION LAYER", "Client Interface & Rendering", [
            ("Thymeleaf Engine", "Server-Side Rendering (SSR) ensuring high security and fast DOM hydration."),
            ("Bootstrap 5.3 & CSS3", "Modern glassmorphism responsive UI supporting mobile & desktop viewports."),
            ("HTML5 & JavaScript", "Interactive DOM updates and dynamic form validation.")
        ], ACCENT_CYAN),
        ("2. BUSINESS LOGIC LAYER", "Spring Boot Application Core", [
            ("Spring Boot 3.2.5", "Dependency injection, autowiring, and component containerization."),
            ("Spring Security 6", "BCrypt authentication provider, session management & CSRF protection."),
            ("Asynchronous Mail", "Java Mail Sender running on @Async background thread executor.")
        ], ACCENT_AMBER),
        ("3. DATA ACCESS LAYER", "Relational Persistence & ORM", [
            ("Spring Data JPA", "Repository interfaces with custom JPQL queries & keyword search."),
            ("Hibernate 6 ORM", "Automatic schema mapping (ddl-auto) and transaction management."),
            ("MySQL 8.0 (XAMPP)", "ACID-compliant relational database storage on port 3306.")
        ], ACCENT_GREEN)
    ]

    for i, (title, sub, bullet_list, col) in enumerate(tiers):
        create_card(s4, 0.8 + (i * 3.9), 1.6, 3.7, 5.0)
        t_box = s4.shapes.add_textbox(Inches(1.0 + (i * 3.9)), Inches(1.8), Inches(3.3), Inches(4.6))
        t_tf = t_box.text_frame
        t_tf.word_wrap = True
        
        th = t_tf.paragraphs[0]
        th.text = title
        th.font.size = Pt(13)
        th.font.bold = True
        th.font.color.rgb = col
        
        ts = t_tf.add_paragraph()
        ts.text = sub
        ts.font.size = Pt(10)
        ts.font.color.rgb = TEXT_MUTED
        ts.space_before = Pt(2)

        for b_name, b_desc in bullet_list:
            bp1 = t_tf.add_paragraph()
            bp1.text = f"• {b_name}"
            bp1.font.size = Pt(12)
            bp1.font.bold = True
            bp1.font.color.rgb = TEXT_WHITE
            bp1.space_before = Pt(8)
            
            bp2 = t_tf.add_paragraph()
            bp2.text = f"  {b_desc}"
            bp2.font.size = Pt(10)
            bp2.font.color.rgb = TEXT_MUTED

    # ==========================================================
    # SLIDE 5: Database Design & ER Model
    # ==========================================================
    notes_5 = "Turning to the data model: the database architecture is normalized and resilient. The central Ticket entity maintains bidirectional relationships with User—both as the ticket creator and the assigned technician. The Comment entity utilizes cascading rules to maintain conversation integrity. Hibernate handles DDL synchronization automatically while preserving existing relational records."
    s5 = add_blank_slide(notes_5)
    add_header(s5, "DATA ARCHITECTURE", "Relational Entity-Relationship (ER) Design")

    entities = [
        ("👤 USERS TABLE", "Core Identity & Credentials", [
            ("id (PK)", "BIGINT (Auto Increment)"),
            ("username", "VARCHAR(50) - UNIQUE"),
            ("password", "VARCHAR(255) - BCrypt Hashed"),
            ("email", "VARCHAR(100) - UNIQUE"),
            ("full_name", "VARCHAR(100)"),
            ("role", "ENUM ('ROLE_USER', 'ROLE_TECH', 'ROLE_ADMIN')"),
            ("department", "VARCHAR(100)")
        ], ACCENT_CYAN),
        ("🎫 TICKETS TABLE", "Issue Tracking & State", [
            ("id (PK)", "BIGINT (Auto Increment)"),
            ("title", "VARCHAR(150) - Indexed"),
            ("description", "TEXT - Issue details"),
            ("priority", "ENUM (LOW, MEDIUM, HIGH, URGENT)"),
            ("status", "ENUM (OPEN, IN_PROGRESS, RESOLVED, CLOSED)"),
            ("user_id (FK)", "BIGINT ➔ users.id (Requester)"),
            ("assigned_to (FK)", "BIGINT ➔ users.id (Technician)")
        ], ACCENT_AMBER),
        ("💬 COMMENTS TABLE", "Threaded Collaboration", [
            ("id (PK)", "BIGINT (Auto Increment)"),
            ("content", "TEXT - Message body"),
            ("is_internal", "BOOLEAN (Tech-only notes)"),
            ("created_at", "DATETIME(6)"),
            ("ticket_id (FK)", "BIGINT ➔ tickets.id (Cascade)"),
            ("user_id (FK)", "BIGINT ➔ users.id (Author)")
        ], ACCENT_GREEN)
    ]

    for i, (title, sub, cols, color) in enumerate(entities):
        create_card(s5, 0.8 + (i * 3.9), 1.6, 3.7, 5.0)
        e_box = s5.shapes.add_textbox(Inches(1.0 + (i * 3.9)), Inches(1.8), Inches(3.3), Inches(4.6))
        e_tf = e_box.text_frame
        e_tf.word_wrap = True
        
        eh = e_tf.paragraphs[0]
        eh.text = title
        eh.font.size = Pt(13)
        eh.font.bold = True
        eh.font.color.rgb = color
        
        es = e_tf.add_paragraph()
        es.text = sub
        es.font.size = Pt(10)
        es.font.color.rgb = TEXT_MUTED

        for col_name, col_type in cols:
            cp = e_tf.add_paragraph()
            cp.text = f"• {col_name}: {col_type}"
            cp.font.size = Pt(10)
            cp.font.color.rgb = TEXT_WHITE
            cp.space_before = Pt(4)

    # ==========================================================
    # SLIDE 6: Security & Role-Based Access Control (RBAC)
    # ==========================================================
    notes_6 = "Security is built into the application core rather than added as an afterthought. Using Spring Security 6, all incoming HTTP requests pass through authorization filters. Passwords are never stored in plaintext—they are hashed using industry-standard BCrypt. The matrix on this slide illustrates how granular access controls prevent horizontal and vertical privilege escalation."
    s6 = add_blank_slide(notes_6)
    add_header(s6, "SECURITY & ACCESS CONTROL", "Spring Security 6 & Role-Based Access Control")

    create_card(s6, 0.8, 1.6, 11.7, 5.0)
    sec_box = s6.shapes.add_textbox(Inches(1.1), Inches(1.8), Inches(11.1), Inches(4.6))
    sec_tf = sec_box.text_frame
    sec_tf.word_wrap = True

    sh = sec_tf.paragraphs[0]
    sh.text = "🔒 GRANULAR ROLE PERMISSION MATRIX"
    sh.font.size = Pt(14)
    sh.font.bold = True
    sh.font.color.rgb = ACCENT_CYAN

    matrix = [
        ("Feature / Capability", "👤 Employee (ROLE_USER)", "🛠️ IT Technician (ROLE_TECH)", "👑 Administrator (ROLE_ADMIN)"),
        ("Create New Support Ticket", "✅ Yes (Self)", "✅ Yes (On Behalf)", "✅ Yes (Full)"),
        ("View Own Ticket History", "✅ Yes", "✅ Yes", "✅ Yes"),
        ("Triage & Reassign Tickets", "❌ No", "✅ Yes (Claim/Assign)", "✅ Yes (Global Override)"),
        ("Update Ticket Status (Open ➔ Resolved)", "❌ No", "✅ Yes", "✅ Yes"),
        ("Post Staff-Only Internal Notes", "❌ No", "✅ Yes", "✅ Yes"),
        ("User Management & Global Analytics", "❌ No", "❌ No", "✅ Yes (Full System)")
    ]

    for row_idx, r in enumerate(matrix):
        p = sec_tf.add_paragraph()
        if row_idx == 0:
            p.text = f"{r[0]:<35} | {r[1]:<25} | {r[2]:<25} | {r[3]}"
            p.font.bold = True
            p.font.size = Pt(11)
            p.font.color.rgb = ACCENT_AMBER
            p.space_before = Pt(8)
        else:
            p.text = f"{r[0]:<35} | {r[1]:<25} | {r[2]:<25} | {r[3]}"
            p.font.size = Pt(11)
            p.font.color.rgb = TEXT_WHITE
            p.space_before = Pt(5)

    # Security highlights
    p_sec = sec_tf.add_paragraph()
    p_sec.text = "\n🛡️ Security Implementations: BCrypt 10-Round Password Hashing  |  CSRF Protection  |  HTTP-Only Cookie Sessions  |  Method Security (@PreAuthorize)"
    p_sec.font.size = Pt(11)
    p_sec.font.bold = True
    p_sec.font.color.rgb = ACCENT_GREEN
    p_sec.space_before = Pt(10)

    # ==========================================================
    # SLIDE 7: Core Features & Workflows
    # ==========================================================
    notes_7 = "This slide illustrates the primary operational workflow. An employee raises a ticket with an assigned category and priority. Technicians instantly see this on their triage dashboard, claim ownership, and transition the status to 'In Progress'. Both parties communicate via nested discussion threads until the technician marks the issue 'Resolved'."
    s7 = add_blank_slide(notes_7)
    add_header(s7, "USER WORKFLOWS", "End-to-End Ticket Lifecycle Progression")

    steps = [
        ("1. SUBMISSION", "Employee raises ticket", "• Select Category\n• Assign Priority\n• Attach Details\n• Status: OPEN", ACCENT_CYAN),
        ("2. TRIAGE", "Assignment to Agent", "• Queue Visibility\n• Claim Ownership\n• Admin Allocation\n• Status: ASSIGNED", ACCENT_AMBER),
        ("3. DIAGNOSIS", "Active Troubleshooting", "• Live Commenting\n• Internal Notes\n• Diagnostic Logs\n• Status: IN PROGRESS", RGBColor(244, 114, 182)),
        ("4. RESOLUTION", "Fix Applied & Verified", "• Solution Summary\n• Email Alert Sent\n• User Validation\n• Status: RESOLVED", ACCENT_GREEN)
    ]

    for i, (st, sub, body, color) in enumerate(steps):
        create_card(s7, 0.8 + (i * 2.95), 1.6, 2.8, 5.0)
        w_box = s7.shapes.add_textbox(Inches(0.95 + (i * 2.95)), Inches(1.8), Inches(2.5), Inches(4.6))
        w_tf = w_box.text_frame
        w_tf.word_wrap = True
        
        wh = w_tf.paragraphs[0]
        wh.text = st
        wh.font.size = Pt(13)
        wh.font.bold = True
        wh.font.color.rgb = color
        
        ws = w_tf.add_paragraph()
        ws.text = sub
        ws.font.size = Pt(10)
        ws.font.color.rgb = TEXT_MUTED
        ws.space_before = Pt(2)

        for line in body.split("\n"):
            wp = w_tf.add_paragraph()
            wp.text = line
            wp.font.size = Pt(11)
            wp.font.color.rgb = TEXT_WHITE
            wp.space_before = Pt(8)

    # ==========================================================
    # SLIDE 8: Automated Email Notification System
    # ==========================================================
    notes_8 = "One of our most impactful technical optimizations is the Notification Engine. Traditional web applications often freeze the UI while contacting SMTP servers. By leveraging Spring's @Async architecture, we offload email dispatches to a background thread pool. The employee receives an immediate UI confirmation in milliseconds, while the email is delivered smoothly in the background."
    s8 = add_blank_slide(notes_8)
    add_header(s8, "NOTIFICATION ENGINE", "Asynchronous Event-Driven Email Alerts")

    create_card(s8, 0.8, 1.6, 5.6, 5.0)
    m1_box = s8.shapes.add_textbox(Inches(1.0), Inches(1.8), Inches(5.2), Inches(4.6))
    m1_tf = m1_box.text_frame
    m1_tf.word_wrap = True
    m1h = m1_tf.paragraphs[0]
    m1h.text = "⚡ @Async NON-BLOCKING ARCHITECTURE"
    m1h.font.size = Pt(13)
    m1h.font.bold = True
    m1h.font.color.rgb = ACCENT_CYAN

    m1_items = [
        ("Synchronous Execution (Traditional Flaw)", "UI freezes for 2–4 seconds waiting for SMTP handshake. Poor user experience and request timeouts."),
        ("Asynchronous Optimization (Our Solution)", "Annotated with @Async. Dispatches tasks to a background thread pool. UI response returns in <15ms."),
        ("Graceful Degradation", "If SMTP is unreachable, system logs warning via SLF4J and continues application logic without crashing.")
    ]
    for title, desc in m1_items:
        p1 = m1_tf.add_paragraph()
        p1.text = f"• {title}:"
        p1.font.bold = True
        p1.font.size = Pt(11)
        p1.font.color.rgb = TEXT_WHITE
        p1.space_before = Pt(8)
        p2 = m1_tf.add_paragraph()
        p2.text = f"  {desc}"
        p2.font.size = Pt(10)
        p2.font.color.rgb = TEXT_MUTED

    create_card(s8, 6.8, 1.6, 5.7, 5.0)
    m2_box = s8.shapes.add_textbox(Inches(7.0), Inches(1.8), Inches(5.3), Inches(4.6))
    m2_tf = m2_box.text_frame
    m2_tf.word_wrap = True
    m2h = m2_tf.paragraphs[0]
    m2h.text = "📩 AUTOMATED NOTIFICATION TRIGGERS"
    m2h.font.size = Pt(13)
    m2h.font.bold = True
    m2h.font.color.rgb = ACCENT_GREEN

    m2_items = [
        ("Ticket Ingestion Trigger", "Employee receives instant email confirmation containing ticket ID, category, and priority summary."),
        ("Technician Assignment Trigger", "Designated support engineer is notified when an urgent ticket is assigned to their queue."),
        ("Status Transition Alert", "Instant alert sent when issue moves from 'In Progress' to 'Resolved' with resolution notes.")
    ]
    for title, desc in m2_items:
        p1 = m2_tf.add_paragraph()
        p1.text = f"• {title}:"
        p1.font.bold = True
        p1.font.size = Pt(11)
        p1.font.color.rgb = TEXT_WHITE
        p1.space_before = Pt(8)
        p2 = m2_tf.add_paragraph()
        p2.text = f"  {desc}"
        p2.font.size = Pt(10)
        p2.font.color.rgb = TEXT_MUTED

    # ==========================================================
    # SLIDE 9: Development Challenges & Solutions
    # ==========================================================
    notes_9 = "During development, we solved critical real-world engineering hurdles. When managing database portability, we structured our JPA configuration to adapt seamlessly between local persistent storage and enterprise MySQL servers. Furthermore, we implemented robust error handling around external services like SMTP to guarantee zero impact on user uptime."
    s9 = add_blank_slide(notes_9)
    add_header(s9, "ENGINEERING CHALLENGES", "Overcoming Real-World Technical Hurdles")

    challs = [
        ("Database Environment Portability", 
         "Challenge: Needing seamless zero-configuration developer testing while ensuring enterprise MySQL compatibility.",
         "Solution: Abstracted datasource configurations in application.properties, allowing instant switching between local storage and XAMPP MySQL.",
         ACCENT_CYAN),
        ("Stateful Sessions & CSRF Security", 
         "Challenge: Securing multipart file avatar uploads and dev consoles without triggering CSRF token invalidations.",
         "Solution: Refactored Spring Security FilterChain with AntPathRequestMatcher and custom frame-options policy.",
         ACCENT_AMBER),
        ("Background Thread Resilience", 
         "Challenge: Handling SMTP connection timeouts without failing user HTTP transactions.",
         "Solution: Wrapped notification services in fault-tolerant asynchronous execution boundaries with structured logging.",
         ACCENT_GREEN)
    ]

    for i, (title, ch, sol, col) in enumerate(challs):
        create_card(s9, 0.8 + (i * 3.9), 1.6, 3.7, 5.0)
        c_box = s9.shapes.add_textbox(Inches(1.0 + (i * 3.9)), Inches(1.8), Inches(3.3), Inches(4.6))
        c_tf = c_box.text_frame
        c_tf.word_wrap = True
        
        ch_p = c_tf.paragraphs[0]
        ch_p.text = title
        ch_p.font.size = Pt(13)
        ch_p.font.bold = True
        ch_p.font.color.rgb = col
        
        p1 = c_tf.add_paragraph()
        p1.text = f"\n⚠️ {ch}"
        p1.font.size = Pt(10)
        p1.font.color.rgb = RGBColor(248, 113, 113)
        p1.space_before = Pt(6)

        p2 = c_tf.add_paragraph()
        p2.text = f"\n✅ {sol}"
        p2.font.size = Pt(10)
        p2.font.color.rgb = RGBColor(167, 243, 208)
        p2.space_before = Pt(6)

    # ==========================================================
    # SLIDE 10: Scalability & Future Roadmap
    # ==========================================================
    notes_10 = "Looking ahead, the architecture is designed for effortless horizontal and vertical scaling. In Phase 1, we can decouple the frontend using REST APIs and React. In Phase 2, we can containerize the service using Docker on AWS. In Phase 3, we envision integrating AI models for automated ticket categorization and SLA countdown timers."
    s10 = add_blank_slide(notes_10)
    add_header(s10, "FUTURE ROADMAP", "Strategic Scalability & Modernization Plan")

    phases = [
        ("PHASE 1: HEADLESS ARCHITECTURE", "Decoupled Modern Frontend", [
            ("RESTful API Controllers", "Expose stateless endpoints with JWT authentication."),
            ("React / Next.js SPA", "Ultra-fast client frontend with optimistic UI updates."),
            ("Mobile Companion App", "Flutter/React Native app for technicians on the move.")
        ], ACCENT_CYAN),
        ("PHASE 2: CLOUD & CONTAINERIZATION", "Infrastructure Modernization", [
            ("Docker Containerization", "Package app into lightweight multi-stage Docker images."),
            ("AWS ECS / Kubernetes", "Auto-scaling deployment on AWS infrastructure."),
            ("Cloud MySQL (RDS)", "Multi-AZ high availability database clustering.")
        ], ACCENT_AMBER),
        ("PHASE 3: AI & SLA INTELLIGENCE", "Smart IT Operations", [
            ("LLM Auto-Triage", "Auto-categorize tickets and suggest solutions from past history."),
            ("Live SLA Timers", "Countdown timers triggering escalation on SLA breaches."),
            ("Sentiment Analysis", "Detect urgent employee dissatisfaction automatically.")
        ], ACCENT_GREEN)
    ]

    for i, (title, sub, bullets, color) in enumerate(phases):
        create_card(s10, 0.8 + (i * 3.9), 1.6, 3.7, 5.0)
        p_box = s10.shapes.add_textbox(Inches(1.0 + (i * 3.9)), Inches(1.8), Inches(3.3), Inches(4.6))
        p_tf = p_box.text_frame
        p_tf.word_wrap = True
        
        ph = p_tf.paragraphs[0]
        ph.text = title
        ph.font.size = Pt(12)
        ph.font.bold = True
        ph.font.color.rgb = color
        
        ps = p_tf.add_paragraph()
        ps.text = sub
        ps.font.size = Pt(10)
        ps.font.color.rgb = TEXT_MUTED
        ps.space_before = Pt(2)

        for b_name, b_desc in bullets:
            bp1 = p_tf.add_paragraph()
            bp1.text = f"• {b_name}:"
            bp1.font.size = Pt(11)
            bp1.font.bold = True
            bp1.font.color.rgb = TEXT_WHITE
            bp1.space_before = Pt(8)
            
            bp2 = p_tf.add_paragraph()
            bp2.text = f"  {b_desc}"
            bp2.font.size = Pt(10)
            bp2.font.color.rgb = TEXT_MUTED

    # ==========================================================
    # SLIDE 11: Conclusion & Project Impact
    # ==========================================================
    notes_11 = "In conclusion, the Nettech Help Desk system meets and exceeds all project requirements. It delivers a robust, secure, and production-ready solution that bridges the IT communication gap. This project has solidified my expertise across full-stack enterprise Java development, relational database engineering, and modern application security."
    s11 = add_blank_slide(notes_11)
    add_header(s11, "CONCLUSION & IMPACT", "Enterprise-Ready Full-Stack Engineering")

    create_card(s11, 0.8, 1.6, 5.6, 5.0)
    c1_box = s11.shapes.add_textbox(Inches(1.0), Inches(1.8), Inches(5.2), Inches(4.6))
    c1_tf = c1_box.text_frame
    c1_tf.word_wrap = True
    c1h = c1_tf.paragraphs[0]
    c1h.text = "🏆 PROJECT DELIVERABLES DELIVERED"
    c1h.font.size = Pt(13)
    c1h.font.bold = True
    c1h.font.color.rgb = ACCENT_GREEN

    delivs = [
        ("Production-Ready Software", "Fully functional full-stack Help Desk system tested and operating on port 8080."),
        ("Robust Security Governance", "Role-Based Access Control verified across Admin, Technician, and User roles."),
        ("Verified Relational Schema", "Full ACID compliance with MySQL 8.0 storage on XAMPP."),
        ("Comprehensive Documentation", "Detailed README, college synopsis report, and PowerPoint deliverables.")
    ]
    for title, desc in delivs:
        p1 = c1_tf.add_paragraph()
        p1.text = f"✅ {title}:"
        p1.font.bold = True
        p1.font.size = Pt(11)
        p1.font.color.rgb = TEXT_WHITE
        p1.space_before = Pt(8)
        p2 = c1_tf.add_paragraph()
        p2.text = f"   {desc}"
        p2.font.size = Pt(10)
        p2.font.color.rgb = TEXT_MUTED

    create_card(s11, 6.8, 1.6, 5.7, 5.0)
    c2_box = s11.shapes.add_textbox(Inches(7.0), Inches(1.8), Inches(5.3), Inches(4.6))
    c2_tf = c2_box.text_frame
    c2_tf.word_wrap = True
    c2h = c2_tf.paragraphs[0]
    c2h.text = "💡 ACADEMIC & TECHNICAL OUTCOMES"
    c2h.font.size = Pt(13)
    c2h.font.bold = True
    c2h.font.color.rgb = ACCENT_CYAN

    learnings = [
        ("Enterprise Framework Mastery", "Applied deep Spring Boot 3 concepts (JPA, Security, Mail, MVC)."),
        ("Relational Database Modeling", "Designed foreign key constraints, cascading policies, and indexing in MySQL."),
        ("Modern Secure Coding", "Implemented BCrypt password encryption and CSRF defense patterns."),
        ("Asynchronous Architecture", "Executed non-blocking event-driven background task processing.")
    ]
    for title, desc in learnings:
        p1 = c2_tf.add_paragraph()
        p1.text = f"💡 {title}:"
        p1.font.bold = True
        p1.font.size = Pt(11)
        p1.font.color.rgb = TEXT_WHITE
        p1.space_before = Pt(8)
        p2 = c2_tf.add_paragraph()
        p2.text = f"   {desc}"
        p2.font.size = Pt(10)
        p2.font.color.rgb = TEXT_MUTED

    # ==========================================================
    # SLIDE 12: Q&A & Demonstration
    # ==========================================================
    notes_12 = "Thank you for your time and attention. I am now delighted to open the floor to any questions from the panel, followed by a live interactive demonstration of the system."
    s12 = add_blank_slide(notes_12)

    create_card(s12, 1.5, 1.2, 10.33, 5.1, bg_color=CARD_BG, border_color=ACCENT_CYAN)
    q_box = s12.shapes.add_textbox(Inches(2.0), Inches(1.6), Inches(9.33), Inches(4.3))
    q_tf = q_box.text_frame
    q_tf.word_wrap = True

    qp1 = q_tf.paragraphs[0]
    qp1.text = "Thank You!"
    qp1.font.size = Pt(36)
    qp1.font.bold = True
    qp1.font.color.rgb = TEXT_WHITE
    qp1.alignment = PP_ALIGN.CENTER

    qp2 = q_tf.add_paragraph()
    qp2.text = "Questions & Live Demonstration"
    qp2.font.size = Pt(20)
    qp2.font.bold = True
    qp2.font.color.rgb = ACCENT_CYAN
    qp2.alignment = PP_ALIGN.CENTER
    qp2.space_before = Pt(10)

    qp3 = q_tf.add_paragraph()
    qp3.text = "\n• Application Portal: http://localhost:8080\n• MySQL Database (phpMyAdmin): http://localhost/phpmyadmin\n• Tech Stack: Java 21 • Spring Boot 3.2 • Spring Security • MySQL 8 • Thymeleaf"
    qp3.font.size = Pt(13)
    qp3.font.color.rgb = TEXT_WHITE
    qp3.alignment = PP_ALIGN.CENTER
    qp3.space_before = Pt(15)

    qp4 = q_tf.add_paragraph()
    qp4.text = "\nPresenter: Niraj Patel  |  MCA Bridge Program  |  BVIMIT, Mumbai University"
    qp4.font.size = Pt(12)
    qp4.font.color.rgb = TEXT_MUTED
    qp4.alignment = PP_ALIGN.CENTER
    qp4.space_before = Pt(15)

    output_path = r"c:\Users\niraj\Downloads\ticket management system\Nettech_Help_Desk_Presentation.pptx"
    prs.save(output_path)
    print(f"Presentation successfully saved to: {output_path}")

if __name__ == "__main__":
    create_presentation()
