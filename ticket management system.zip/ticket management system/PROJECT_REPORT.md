# Project Report: Nettech Help Desk Ticket Management System

**Submitted by:** Niraj Patel  
**Program:** Master of Computer Applications (MCA) Bridge Program  
**Institution:** BVIMIT, Mumbai University  

---

## 1. Abstract
The Nettech Help Desk Ticket Management System is a centralized, web-based platform designed to streamline internal IT support operations. In modern corporate environments, tracking employee technical issues via unstructured communication channels leads to inefficiencies and lost data. This system provides a structured, full-stack solution where employees can log detailed support tickets, and IT personnel can efficiently categorize, track, and resolve them. 

## 2. Project Objectives
*   To develop a secure, role-based authentication system distinguishing between standard Employees, Support Technicians, and Administrators.
*   To establish a persistent, relational database schema for tracking the complete lifecycle of a support ticket.
*   To implement dynamic search and filtering capabilities for efficient ticket retrieval.
*   To integrate advanced features including physical file uploads for user avatars and asynchronous email notifications for status updates.

## 3. System Architecture & Modules
The application follows a standard Model-View-Controller (MVC) architectural pattern built on the Spring Boot framework.

### 3.1 Authentication & Security Module
Utilizes Spring Security 6 with BCrypt password hashing. The module intercepts all HTTP requests, ensuring unauthenticated users are redirected to the login portal and administrative routes are strictly protected via route-level authorization.

### 3.2 User Operations Module
*   **Ticket Generation:** Employees can raise tickets defining the issue subject, detailed description, and urgency priority.
*   **Profile Customization:** Users can manage their personal details, securely change passwords, and upload profile pictures, handled via `MultipartFile` processing.

### 3.3 Technician & Administrative Module
*   **Dashboard Metrics:** Provides administrators with high-level statistical counts of system-wide ticket statuses.
*   **Status Management:** Technicians can update ticket progression (Open → In Progress → Resolved) and communicate directly with users via nested comment threads.
*   **Search & Filtering:** A custom Spring Data JPA query implementation allows rapid keyword searching across the database.

### 3.4 Notification Module
Leverages `spring-boot-starter-mail` and the `@Async` annotation to dispatch automated email updates to employees when their ticket status changes, without blocking the main application thread.

## 4. Technology Stack Overview
*   **Application Logic:** Java 21, Spring Boot 3.2
*   **Data Persistence:** Hibernate ORM, Spring Data JPA, MySQL 8.4
*   **Presentation Layer:** Thymeleaf, Bootstrap 5 CSS Framework
*   **Dependency Management:** Apache Maven

## 5. Conclusion & Learning Outcomes
The successful deployment of the Nettech Help Desk System demonstrates a comprehensive application of full-stack enterprise architecture. Key learning outcomes include mastering relational database design, implementing secure RESTful concepts, handling multipart data streams for file storage, and configuring asynchronous background processes in a modern Java ecosystem.
