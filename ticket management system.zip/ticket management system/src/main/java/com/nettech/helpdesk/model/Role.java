package com.nettech.helpdesk.model;

public enum Role {
    ROLE_USER("User / Employee"),
    ROLE_TECHNICIAN("IT Support Technician"),
    ROLE_ADMIN("System Administrator");

    private final String displayName;

    Role(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }
}
