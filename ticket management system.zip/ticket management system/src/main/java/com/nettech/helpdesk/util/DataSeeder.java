package com.nettech.helpdesk.util;

import com.nettech.helpdesk.model.Role;
import com.nettech.helpdesk.model.Ticket;
import com.nettech.helpdesk.model.TicketPriority;
import com.nettech.helpdesk.model.TicketStatus;
import com.nettech.helpdesk.model.User;
import com.nettech.helpdesk.service.CommentService;
import com.nettech.helpdesk.service.TicketService;
import com.nettech.helpdesk.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataSeeder implements CommandLineRunner {

    private final UserService userService;
    private final TicketService ticketService;
    private final CommentService commentService;

    @Autowired
    public DataSeeder(UserService userService, TicketService ticketService, CommentService commentService) {
        this.userService = userService;
        this.ticketService = ticketService;
        this.commentService = commentService;
    }

    @Override
    public void run(String... args) throws Exception {
        if (userService.findAllUsers().isEmpty()) {
            System.out.println(">>> Seeding initial Help Desk users and ticket data...");

            // Create Users
            User admin = userService.registerUser("admin", "admin123", "admin@nettech.com", "System Administrator", Role.ROLE_ADMIN, "IT Operations");
            User tech1 = userService.registerUser("tech_sarah", "tech123", "sarah.tech@nettech.com", "Sarah Connor (IT Tech)", Role.ROLE_TECHNICIAN, "Infrastructure");
            User tech2 = userService.registerUser("tech_david", "tech123", "david.tech@nettech.com", "David Miller (Software Support)", Role.ROLE_TECHNICIAN, "Software Support");
            User user1 = userService.registerUser("john_doe", "user123", "john.doe@nettech.com", "John Doe", Role.ROLE_USER, "Finance");
            User user2 = userService.registerUser("alice_smith", "user123", "alice.smith@nettech.com", "Alice Smith", Role.ROLE_USER, "Marketing");

            // Seed Ticket 1
            Ticket ticket1 = ticketService.createTicket(
                    "VPN Connection failing from home office",
                    "Unable to connect to GlobalProtect VPN after the recent Windows 11 system update. Error code: 80070035.",
                    "Network & Connectivity",
                    TicketPriority.HIGH,
                    user1
            );
            ticketService.assignTicket(ticket1.getId(), tech1);
            commentService.addComment(ticket1.getId(), tech1, "Hi John, I am looking into your VPN profile on the gateway.", false);
            commentService.addComment(ticket1.getId(), tech1, "Internal note: Check RADIUS server authentication logs.", true);

            // Seed Ticket 2
            Ticket ticket2 = ticketService.createTicket(
                    "Need dual monitor setup for Marketing workstation",
                    "Requesting a secondary 27-inch 4K monitor and HDMI docking adapter for video editing work.",
                    "Hardware Request",
                    TicketPriority.MEDIUM,
                    user2
            );
            ticketService.assignTicket(ticket2.getId(), tech2);

            // Seed Ticket 3
            Ticket ticket3 = ticketService.createTicket(
                    "ERP System password reset required",
                    "Account locked out after entering incorrect password 3 times.",
                    "Account Access",
                    TicketPriority.URGENT,
                    user1
            );
            ticketService.updateTicketStatus(ticket3.getId(), TicketStatus.RESOLVED);
            commentService.addComment(ticket3.getId(), admin, "Temporary password sent via encrypted email. Ticket marked resolved.", false);

            // Seed Ticket 4
            Ticket ticket4 = ticketService.createTicket(
                    "Printer in 3rd Floor Finance Bay out of toner",
                    "HP LaserJet Pro printer displays 'Replace Magenta Cartridge' and refuses queue printing.",
                    "Hardware Maintenance",
                    TicketPriority.LOW,
                    user1
            );

            System.out.println(">>> Data seeding complete!");
        }
    }
}
