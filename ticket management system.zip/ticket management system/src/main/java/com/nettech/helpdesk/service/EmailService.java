package com.nettech.helpdesk.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

    private static final Logger logger = LoggerFactory.getLogger(EmailService.class);

    private final JavaMailSender mailSender;

    @Autowired(required = false)
    public EmailService(JavaMailSender mailSender) {
        this.mailSender = mailSender;
    }

    @Async
    public void sendTicketUpdateEmail(String userEmail, String ticketTitle, String newStatus) {
        logger.info("Preparing asynchronous email notification for {} regarding ticket: '{}' -> New Status: {}", userEmail, ticketTitle, newStatus);

        if (mailSender == null) {
            logger.warn("JavaMailSender bean is not available. Email notification skipped for {}", userEmail);
            return;
        }

        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom("noreply@nettech.com");
            message.setTo(userEmail);
            message.setSubject("Ticket Status Update: " + ticketTitle);
            message.setText("Hello,\n\nYour support ticket '" + ticketTitle + "' status has been updated to: " + newStatus + ".\n\nLog in to Nettech Help Desk to view updates.\n\nBest regards,\nNettech IT Support Team");

            mailSender.send(message);
            logger.info("Email notification successfully sent to {}", userEmail);
        } catch (Exception e) {
            logger.warn("SMTP email sending to {} skipped/failed (Credentials placeholder active): {}. Application logic continued normally.", userEmail, e.getMessage());
        }
    }
}
