package com.nettech.helpdesk.repository;

import com.nettech.helpdesk.model.Ticket;
import com.nettech.helpdesk.model.TicketPriority;
import com.nettech.helpdesk.model.TicketStatus;
import com.nettech.helpdesk.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface TicketRepository extends JpaRepository<Ticket, Long> {

    Optional<Ticket> findByTicketCode(String ticketCode);

    List<Ticket> findByTitleContainingIgnoreCaseOrDescriptionContainingIgnoreCase(String title, String description);

    List<Ticket> findByCreatorOrderByCreatedAtDesc(User creator);

    List<Ticket> findByAssigneeOrderByCreatedAtDesc(User assignee);

    List<Ticket> findAllByOrderByCreatedAtDesc();

    List<Ticket> findByStatusOrderByCreatedAtDesc(TicketStatus status);

    long countByStatus(TicketStatus status);

    long countByPriority(TicketPriority priority);

    long countByCreator(User creator);

    long countByAssignee(User assignee);

    @Query("SELECT t FROM Ticket t WHERE " +
           "(:keyword IS NULL OR :keyword = '' OR LOWER(t.title) LIKE LOWER(CONCAT('%', :keyword, '%')) OR LOWER(t.ticketCode) LIKE LOWER(CONCAT('%', :keyword, '%'))) AND " +
           "(:status IS NULL OR t.status = :status) AND " +
           "(:priority IS NULL OR t.priority = :priority) " +
           "ORDER BY t.createdAt DESC")
    List<Ticket> filterTickets(@Param("keyword") String keyword,
                              @Param("status") TicketStatus status,
                              @Param("priority") TicketPriority priority);

    @Query("SELECT t FROM Ticket t WHERE t.creator = :creator AND " +
           "(:keyword IS NULL OR :keyword = '' OR LOWER(t.title) LIKE LOWER(CONCAT('%', :keyword, '%')) OR LOWER(t.ticketCode) LIKE LOWER(CONCAT('%', :keyword, '%'))) AND " +
           "(:status IS NULL OR t.status = :status) AND " +
           "(:priority IS NULL OR t.priority = :priority) " +
           "ORDER BY t.createdAt DESC")
    List<Ticket> filterUserTickets(@Param("creator") User creator,
                                  @Param("keyword") String keyword,
                                  @Param("status") TicketStatus status,
                                  @Param("priority") TicketPriority priority);
}
