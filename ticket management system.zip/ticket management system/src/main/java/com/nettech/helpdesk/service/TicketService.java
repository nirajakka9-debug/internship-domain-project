package com.nettech.helpdesk.service;

import com.nettech.helpdesk.model.Ticket;
import com.nettech.helpdesk.model.TicketPriority;
import com.nettech.helpdesk.model.TicketStatus;
import com.nettech.helpdesk.model.User;
import com.nettech.helpdesk.repository.TicketRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class TicketService {

    private final TicketRepository ticketRepository;
    private final EmailService emailService;

    @Autowired
    public TicketService(TicketRepository ticketRepository, EmailService emailService) {
        this.ticketRepository = ticketRepository;
        this.emailService = emailService;
    }

    @Transactional
    public Ticket createTicket(String title, String description, String category, TicketPriority priority, User creator) {
        Ticket ticket = new Ticket(title, description, category, priority, creator);
        ticket = ticketRepository.save(ticket);
        
        // Auto-generate ticket code e.g. NT-2026-1001
        String ticketCode = String.format("NT-2026-%04d", ticket.getId());
        ticket.setTicketCode(ticketCode);
        
        return ticketRepository.save(ticket);
    }

    public Optional<Ticket> findById(Long id) {
        return ticketRepository.findById(id);
    }

    public Optional<Ticket> findByTicketCode(String ticketCode) {
        return ticketRepository.findByTicketCode(ticketCode);
    }

    public List<Ticket> findAllTickets() {
        return ticketRepository.findAllByOrderByCreatedAtDesc();
    }

    public List<Ticket> findTicketsByCreator(User creator) {
        return ticketRepository.findByCreatorOrderByCreatedAtDesc(creator);
    }

    public List<Ticket> findTicketsByAssignee(User assignee) {
        return ticketRepository.findByAssigneeOrderByCreatedAtDesc(assignee);
    }

    public List<Ticket> searchTickets(String keyword) {
        if (keyword != null && !keyword.trim().isEmpty()) {
            return ticketRepository.findByTitleContainingIgnoreCaseOrDescriptionContainingIgnoreCase(keyword.trim(), keyword.trim());
        }
        return findAllTickets();
    }

    public List<Ticket> searchUserTickets(User creator, String keyword) {
        if (keyword != null && !keyword.trim().isEmpty()) {
            List<Ticket> results = ticketRepository.findByTitleContainingIgnoreCaseOrDescriptionContainingIgnoreCase(keyword.trim(), keyword.trim());
            return results.stream()
                    .filter(t -> t.getCreator().getId().equals(creator.getId()))
                    .toList();
        }
        return findTicketsByCreator(creator);
    }

    public List<Ticket> filterTickets(String keyword, TicketStatus status, TicketPriority priority) {
        String search = (keyword != null && !keyword.trim().isEmpty()) ? keyword.trim() : null;
        return ticketRepository.filterTickets(search, status, priority);
    }

    public List<Ticket> filterUserTickets(User creator, String keyword, TicketStatus status, TicketPriority priority) {
        String search = (keyword != null && !keyword.trim().isEmpty()) ? keyword.trim() : null;
        return ticketRepository.filterUserTickets(creator, search, status, priority);
    }

    @Transactional
    public Ticket updateTicketStatus(Long ticketId, TicketStatus newStatus) {
        Ticket ticket = ticketRepository.findById(ticketId)
                .orElseThrow(() -> new IllegalArgumentException("Ticket not found with id: " + ticketId));
        ticket.setStatus(newStatus);
        Ticket updated = ticketRepository.save(ticket);

        if (updated.getCreator() != null && updated.getCreator().getEmail() != null) {
            emailService.sendTicketUpdateEmail(updated.getCreator().getEmail(), updated.getTitle(), newStatus.getLabel());
        }

        return updated;
    }

    @Transactional
    public Ticket assignTicket(Long ticketId, User assignee) {
        Ticket ticket = ticketRepository.findById(ticketId)
                .orElseThrow(() -> new IllegalArgumentException("Ticket not found with id: " + ticketId));
        ticket.setAssignee(assignee);
        if (ticket.getStatus() == TicketStatus.OPEN) {
            ticket.setStatus(TicketStatus.IN_PROGRESS);
        }
        return ticketRepository.save(ticket);
    }

    public Map<String, Long> getMetrics() {
        Map<String, Long> metrics = new HashMap<>();
        metrics.put("total", ticketRepository.count());
        metrics.put("open", ticketRepository.countByStatus(TicketStatus.OPEN));
        metrics.put("inProgress", ticketRepository.countByStatus(TicketStatus.IN_PROGRESS));
        metrics.put("resolved", ticketRepository.countByStatus(TicketStatus.RESOLVED));
        metrics.put("closed", ticketRepository.countByStatus(TicketStatus.CLOSED));
        metrics.put("urgent", ticketRepository.countByPriority(TicketPriority.URGENT));
        return metrics;
    }

    public Map<String, Long> getUserMetrics(User user) {
        Map<String, Long> metrics = new HashMap<>();
        List<Ticket> userTickets = ticketRepository.findByCreatorOrderByCreatedAtDesc(user);
        metrics.put("total", (long) userTickets.size());
        metrics.put("open", userTickets.stream().filter(t -> t.getStatus() == TicketStatus.OPEN).count());
        metrics.put("inProgress", userTickets.stream().filter(t -> t.getStatus() == TicketStatus.IN_PROGRESS).count());
        metrics.put("resolved", userTickets.stream().filter(t -> t.getStatus() == TicketStatus.RESOLVED).count());
        metrics.put("closed", userTickets.stream().filter(t -> t.getStatus() == TicketStatus.CLOSED).count());
        return metrics;
    }
}
