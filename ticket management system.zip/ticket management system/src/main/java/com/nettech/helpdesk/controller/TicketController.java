package com.nettech.helpdesk.controller;

import com.nettech.helpdesk.model.*;
import com.nettech.helpdesk.service.CommentService;
import com.nettech.helpdesk.service.TicketService;
import com.nettech.helpdesk.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/tickets")
public class TicketController {

    private final TicketService ticketService;
    private final UserService userService;
    private final CommentService commentService;

    @Autowired
    public TicketController(TicketService ticketService, UserService userService, CommentService commentService) {
        this.ticketService = ticketService;
        this.userService = userService;
        this.commentService = commentService;
    }

    @GetMapping
    public String listTickets(@RequestParam(value = "keyword", required = false) String keyword,
                              @RequestParam(value = "status", required = false) TicketStatus status,
                              @RequestParam(value = "priority", required = false) TicketPriority priority,
                              Authentication authentication,
                              Model model) {
        User user = userService.findByUsername(authentication.getName()).orElseThrow();
        List<Ticket> tickets;

        if (status == null && priority == null && keyword != null && !keyword.trim().isEmpty()) {
            if (user.getRole() == Role.ROLE_ADMIN || user.getRole() == Role.ROLE_TECHNICIAN) {
                tickets = ticketService.searchTickets(keyword);
            } else {
                tickets = ticketService.searchUserTickets(user, keyword);
            }
        } else if (user.getRole() == Role.ROLE_ADMIN || user.getRole() == Role.ROLE_TECHNICIAN) {
            tickets = ticketService.filterTickets(keyword, status, priority);
        } else {
            tickets = ticketService.filterUserTickets(user, keyword, status, priority);
        }

        model.addAttribute("tickets", tickets);
        model.addAttribute("keyword", keyword);
        model.addAttribute("selectedStatus", status);
        model.addAttribute("selectedPriority", priority);
        model.addAttribute("statuses", TicketStatus.values());
        model.addAttribute("priorities", TicketPriority.values());
        model.addAttribute("currentUser", user);

        return "tickets/list";
    }

    @GetMapping("/new")
    public String newTicketForm(Model model) {
        model.addAttribute("priorities", TicketPriority.values());
        return "tickets/create";
    }

    @PostMapping
    public String createTicket(@RequestParam("title") String title,
                               @RequestParam("description") String description,
                               @RequestParam("category") String category,
                               @RequestParam("priority") TicketPriority priority,
                               Authentication authentication,
                               RedirectAttributes redirectAttributes) {
        User creator = userService.findByUsername(authentication.getName()).orElseThrow();
        Ticket ticket = ticketService.createTicket(title, description, category, priority, creator);
        redirectAttributes.addFlashAttribute("successMessage", "Ticket " + ticket.getTicketCode() + " raised successfully!");
        return "redirect:/tickets/" + ticket.getId();
    }

    @GetMapping("/{id}")
    public String ticketDetail(@PathVariable("id") Long id, Authentication authentication, Model model) {
        User user = userService.findByUsername(authentication.getName()).orElseThrow();
        Ticket ticket = ticketService.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Ticket not found: " + id));

        // Access check
        if (user.getRole() == Role.ROLE_USER && !ticket.getCreator().getId().equals(user.getId())) {
            return "error/403";
        }

        boolean canManage = user.getRole() == Role.ROLE_ADMIN || user.getRole() == Role.ROLE_TECHNICIAN;
        List<Comment> comments = commentService.getCommentsForTicket(ticket, canManage);

        model.addAttribute("ticket", ticket);
        model.addAttribute("comments", comments);
        model.addAttribute("currentUser", user);
        model.addAttribute("canManage", canManage);
        model.addAttribute("statuses", TicketStatus.values());
        model.addAttribute("technicians", userService.findTechnicians());

        return "tickets/detail";
    }

    @PostMapping("/{id}/status")
    public String updateStatus(@PathVariable("id") Long id,
                               @RequestParam("status") TicketStatus status,
                               Authentication authentication,
                               RedirectAttributes redirectAttributes) {
        User user = userService.findByUsername(authentication.getName()).orElseThrow();
        Ticket ticket = ticketService.findById(id).orElseThrow();

        if (user.getRole() == Role.ROLE_USER && !ticket.getCreator().getId().equals(user.getId())) {
            return "error/403";
        }

        ticketService.updateTicketStatus(id, status);
        redirectAttributes.addFlashAttribute("successMessage", "Ticket status updated to " + status.getLabel());
        return "redirect:/tickets/" + id;
    }

    @PostMapping("/{id}/assign")
    public String assignTicket(@PathVariable("id") Long id,
                               @RequestParam("assigneeId") Long assigneeId,
                               Authentication authentication,
                               RedirectAttributes redirectAttributes) {
        User user = userService.findByUsername(authentication.getName()).orElseThrow();
        if (user.getRole() == Role.ROLE_USER) {
            return "error/403";
        }

        User assignee = userService.findById(assigneeId)
                .orElseThrow(() -> new IllegalArgumentException("Assignee not found"));

        ticketService.assignTicket(id, assignee);
        redirectAttributes.addFlashAttribute("successMessage", "Ticket assigned to " + assignee.getFullName());
        return "redirect:/tickets/" + id;
    }

    @PostMapping("/{id}/comments")
    public String addComment(@PathVariable("id") Long id,
                             @RequestParam("content") String content,
                             @RequestParam(value = "isInternalNote", defaultValue = "false") boolean isInternalNote,
                             Authentication authentication,
                             RedirectAttributes redirectAttributes) {
        User author = userService.findByUsername(authentication.getName()).orElseThrow();
        Ticket ticket = ticketService.findById(id).orElseThrow();

        if (author.getRole() == Role.ROLE_USER && !ticket.getCreator().getId().equals(author.getId())) {
            return "error/403";
        }

        commentService.addComment(id, author, content, isInternalNote);
        redirectAttributes.addFlashAttribute("successMessage", "Response posted successfully.");
        return "redirect:/tickets/" + id;
    }
}
