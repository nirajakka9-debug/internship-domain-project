package com.nettech.helpdesk.model;

public enum TicketPriority {
    LOW("Low", "badge-low"),
    MEDIUM("Medium", "badge-medium"),
    HIGH("High", "badge-high"),
    URGENT("Urgent", "badge-urgent");

    private final String label;
    private final String cssClass;

    TicketPriority(String label, String cssClass) {
        this.label = label;
        this.cssClass = cssClass;
    }

    public String getLabel() {
        return label;
    }

    public String getCssClass() {
        return cssClass;
    }
}
