package com.nettech.helpdesk.controller;

import com.nettech.helpdesk.model.User;
import com.nettech.helpdesk.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import org.springframework.web.multipart.MultipartFile;

@Controller
public class ProfileController {

    private final UserService userService;

    @Autowired
    public ProfileController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/profile")
    public String viewProfile(Authentication authentication, Model model) {
        String username = authentication.getName();
        User user = userService.findByUsername(username)
                .orElseThrow(() -> new IllegalStateException("User not found in database."));

        model.addAttribute("user", user);
        return "profile";
    }

    @PostMapping("/profile/edit")
    public String editProfile(@RequestParam("email") String email,
                              @RequestParam("fullName") String fullName,
                              @RequestParam("department") String department,
                              @RequestParam(value = "newPassword", required = false) String newPassword,
                              @RequestParam(value = "avatar", required = false) MultipartFile avatar,
                              Authentication authentication,
                              RedirectAttributes redirectAttributes) {
        String username = authentication.getName();
        User currentUser = userService.findByUsername(username).orElseThrow();

        try {
            userService.updateUserProfile(currentUser.getId(), email, fullName, department, newPassword, avatar);
            redirectAttributes.addFlashAttribute("successMessage", "Profile updated successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Error updating profile: " + e.getMessage());
        }

        return "redirect:/profile";
    }
}
