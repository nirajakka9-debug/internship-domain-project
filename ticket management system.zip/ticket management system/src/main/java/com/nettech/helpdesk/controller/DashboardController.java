package com.nettech.helpdesk.controller;

import com.nettech.helpdesk.model.Role;
import com.nettech.helpdesk.model.Ticket;
import com.nettech.helpdesk.model.User;
import com.nettech.helpdesk.service.TicketService;
import com.nettech.helpdesk.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;
import java.util.Map;

@Controller
public class DashboardController {

    private final TicketService ticketService;
    private final UserService userService;

    @Autowired
    public DashboardController(TicketService ticketService, UserService userService) {
        this.ticketService = ticketService;
        this.userService = userService;
    }

    @GetMapping("/")
    public String index() {
        return "redirect:/dashboard";
    }

    @GetMapping("/dashboard")
    public String dashboard(@RequestParam(value = "keyword", required = false) String keyword,
                            Authentication authentication,
                            Model model) {
        String username = authentication.getName();
        User user = userService.findByUsername(username)
                .orElseThrow(() -> new IllegalStateException("Authenticated user not found in database."));

        model.addAttribute("currentUser", user);
        model.addAttribute("keyword", keyword);

        if (user.getRole() == Role.ROLE_ADMIN || user.getRole() == Role.ROLE_TECHNICIAN) {
            Map<String, Long> metrics = ticketService.getMetrics();
            List<Ticket> recentTickets;
            if (keyword != null && !keyword.trim().isEmpty()) {
                recentTickets = ticketService.searchTickets(keyword);
            } else {
                recentTickets = ticketService.findAllTickets();
                if (recentTickets.size() > 10) {
                    recentTickets = recentTickets.subList(0, 10);
                }
            }
            model.addAttribute("metrics", metrics);
            model.addAttribute("recentTickets", recentTickets);
            model.addAttribute("technicians", userService.findTechnicians());
            return "dashboard/admin";
        } else {
            Map<String, Long> metrics = ticketService.getUserMetrics(user);
            List<Ticket> myTickets;
            if (keyword != null && !keyword.trim().isEmpty()) {
                myTickets = ticketService.searchUserTickets(user, keyword);
            } else {
                myTickets = ticketService.findTicketsByCreator(user);
            }
            model.addAttribute("metrics", metrics);
            model.addAttribute("myTickets", myTickets);
            return "dashboard/user";
        }
    }
}
