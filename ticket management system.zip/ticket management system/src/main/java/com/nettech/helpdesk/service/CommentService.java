package com.nettech.helpdesk.service;

import com.nettech.helpdesk.model.Comment;
import com.nettech.helpdesk.model.Ticket;
import com.nettech.helpdesk.model.User;
import com.nettech.helpdesk.repository.CommentRepository;
import com.nettech.helpdesk.repository.TicketRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class CommentService {

    private final CommentRepository commentRepository;
    private final TicketRepository ticketRepository;

    @Autowired
    public CommentService(CommentRepository commentRepository, TicketRepository ticketRepository) {
        this.commentRepository = commentRepository;
        this.ticketRepository = ticketRepository;
    }

    @Transactional
    public Comment addComment(Long ticketId, User author, String content, boolean isInternalNote) {
        Ticket ticket = ticketRepository.findById(ticketId)
                .orElseThrow(() -> new IllegalArgumentException("Ticket not found: " + ticketId));

        Comment comment = new Comment(ticket, author, content, isInternalNote);
        commentRepository.save(comment);

        ticket.addComment(comment);
        ticketRepository.save(ticket);

        return comment;
    }

    public List<Comment> getCommentsForTicket(Ticket ticket, boolean canViewInternalNotes) {
        if (canViewInternalNotes) {
            return commentRepository.findByTicketOrderByCreatedAtAsc(ticket);
        } else {
            return commentRepository.findByTicketAndIsInternalNoteFalseOrderByCreatedAtAsc(ticket);
        }
    }
}
