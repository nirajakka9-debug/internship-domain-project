package com.nettech.helpdesk.controller;

import com.nettech.helpdesk.model.Role;
import com.nettech.helpdesk.model.User;
import com.nettech.helpdesk.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/admin")
public class AdminController {

    private final UserService userService;

    @Autowired
    public AdminController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/users")
    public String userManagement(Model model) {
        List<User> users = userService.findAllUsers();
        model.addAttribute("users", users);
        model.addAttribute("roles", Role.values());
        return "admin/users";
    }

    @PostMapping("/users/{id}/role")
    public String updateUserRole(@PathVariable("id") Long userId,
                                 @RequestParam("role") Role role,
                                 RedirectAttributes redirectAttributes) {
        User updated = userService.updateUserRole(userId, role);
        redirectAttributes.addFlashAttribute("successMessage", "Role for user " + updated.getUsername() + " updated to " + role.getDisplayName());
        return "redirect:/admin/users";
    }
}
