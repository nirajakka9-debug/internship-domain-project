package com.nettech.helpdesk.model;

public enum TicketStatus {
    OPEN("Open", "badge-status-open"),
    IN_PROGRESS("In Progress", "badge-status-inprogress"),
    RESOLVED("Resolved", "badge-status-resolved"),
    CLOSED("Closed", "badge-status-closed");

    private final String label;
    private final String cssClass;

    TicketStatus(String label, String cssClass) {
        this.label = label;
        this.cssClass = cssClass;
    }

    public String getLabel() {
        return label;
    }

    public String getCssClass() {
        return cssClass;
    }
}
