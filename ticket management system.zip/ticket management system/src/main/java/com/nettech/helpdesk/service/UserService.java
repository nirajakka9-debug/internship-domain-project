package com.nettech.helpdesk.service;

import com.nettech.helpdesk.model.Role;
import com.nettech.helpdesk.model.User;
import com.nettech.helpdesk.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Autowired
    public UserService(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Transactional
    public User registerUser(String username, String password, String email, String fullName, Role role, String department) {
        if (userRepository.existsByUsername(username)) {
            throw new IllegalArgumentException("Username '" + username + "' is already taken.");
        }
        if (userRepository.existsByEmail(email)) {
            throw new IllegalArgumentException("Email '" + email + "' is already registered.");
        }

        String encodedPassword = passwordEncoder.encode(password);
        User user = new User(username, encodedPassword, email, fullName, role, department);
        return userRepository.save(user);
    }

    public Optional<User> findByUsername(String username) {
        return userRepository.findByUsername(username);
    }

    public Optional<User> findById(Long id) {
        return userRepository.findById(id);
    }

    public List<User> findAllUsers() {
        return userRepository.findAll();
    }

    public List<User> findTechnicians() {
        return userRepository.findByRole(Role.ROLE_TECHNICIAN);
    }

    @Transactional
    public User updateUserRole(Long userId, Role newRole) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not found: " + userId));
        user.setRole(newRole);
        return userRepository.save(user);
    }

    @Transactional
    public User updateUserProfile(Long userId, String email, String fullName, String department, String newPassword) {
        return updateUserProfile(userId, email, fullName, department, newPassword, null);
    }

    @Transactional
    public User updateUserProfile(Long userId, String email, String fullName, String department, String newPassword, MultipartFile avatarFile) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not found: " + userId));

        if (!user.getEmail().equalsIgnoreCase(email) && userRepository.existsByEmail(email)) {
            throw new IllegalArgumentException("Email '" + email + "' is already registered to another user.");
        }

        user.setEmail(email);
        if (fullName != null && !fullName.trim().isEmpty()) {
            user.setFullName(fullName.trim());
        }
        if (department != null) {
            user.setDepartment(department.trim());
        }
        if (newPassword != null && !newPassword.trim().isEmpty()) {
            user.setPassword(passwordEncoder.encode(newPassword.trim()));
        }

        if (avatarFile != null && !avatarFile.isEmpty()) {
            try {
                String originalFilename = avatarFile.getOriginalFilename();
                String fileExtension = "";
                if (originalFilename != null && originalFilename.contains(".")) {
                    fileExtension = originalFilename.substring(originalFilename.lastIndexOf("."));
                } else {
                    fileExtension = ".png";
                }

                String filename = UUID.randomUUID().toString() + fileExtension;

                // Save to static resources source folder
                Path uploadPathSrc = Paths.get("src/main/resources/static/uploads/avatars");
                if (!Files.exists(uploadPathSrc)) {
                    Files.createDirectories(uploadPathSrc);
                }
                Path filePathSrc = uploadPathSrc.resolve(filename);
                Files.copy(avatarFile.getInputStream(), filePathSrc, StandardCopyOption.REPLACE_EXISTING);

                // Save to target classes folder so live server picks it up immediately
                Path uploadPathTarget = Paths.get("target/classes/static/uploads/avatars");
                if (Files.exists(uploadPathTarget.getParent())) {
                    if (!Files.exists(uploadPathTarget)) {
                        Files.createDirectories(uploadPathTarget);
                    }
                    Path filePathTarget = uploadPathTarget.resolve(filename);
                    Files.copy(filePathSrc, filePathTarget, StandardCopyOption.REPLACE_EXISTING);
                }

                user.setProfilePicture("/uploads/avatars/" + filename);
            } catch (IOException e) {
                throw new RuntimeException("Could not store profile picture file.", e);
            }
        }

        return userRepository.save(user);
    }
}
